from flask import Flask, render_template, request, url_for, redirect, session


app = Flask(__name__, static_url_path='', static_folder='static', template_folder='templates')
app.secret_key = 'any random string'
import pymysql
import datetime
global sessions
sessions=False

@app.route('/')
def home():
	global sessions
	if sessions== False:
		return login()
	else:
		return app.send_static_file('index.html')



@app.route('/login',methods = ['POST', 'GET'])
def login():
   global sessions
   if sessions == True:
         return home()

   if request.method == 'POST':
      custName=[]
      custPassword=[]
      
 
      usrn = request.form["Username"]
      uspw = request.form["pwd"]
      
      db = pymysql.connect("localhost", "mky", "kaistyhoma", "Foundation")
      cursor = db.cursor()

      sql=("SELECT Email, Password FROM Donator WHERE Email = '"+usrn+"'")
      cursor.execute(sql)

      db.commit()
      results = cursor.fetchall()
      for row in results:
          custName.append(str(row[0]))
          custPassword.append(str(row[1]))
      
      
      if ((str(usrn) in custName) and  (str(uspw) in custPassword)) :
         global sessions
         sessions = True
         return home()
      else:
         return render_template('login3.html',test="wrong password")
   else:
         return render_template('login3.html')

@app.route("/logout")
def logout():
   global sessions
   sessions = False
   return login()

@app.route("/register",methods = ['POST', 'GET'])
def register():
   if request.method == 'POST':
      
      fir_nam= request.form['first_name']
      las_nam= request.form['last_name']
      email_address=request.form['email']
      uspw = request.form['pwd']

   


      db = pymysql.connect("localhost", "mky", "kaistyhoma", "Foundation")

      cursor = db.cursor() 

      x= str(fir_nam)


    # sql = """INSERT INTO Donator (Donator ID,Password, First  Name, Last Name, Email) VALUES ('%d','%s','%s','%s','%s')"""\
    # %(0,str(uspw), str(fir_nam),  str(las_nam), str(email_address))

      sql = """INSERT INTO Donator (0,str(uspw), str(fir_nam),  str(las_nam), str(email_address)) VALUES ('%d','%s','%s','%s','%s')"""

      try:
         cursor.execute(sql)
         db.commit()
      except:

         db.rollback() 
         return render_template('login3.html',test="you have successfully registered")
      db.close()
      return render_template('register.html')
   else:
      return render_template('register.html')
      

if __name__ == '__main__':
   app.run(debug = True)
